package ast;

import crux.Symbol;

public interface Declaration extends Visitable {
	
	public Symbol symbol();
}
