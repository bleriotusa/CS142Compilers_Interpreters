package ast;

public interface Expression extends Visitable {

}
